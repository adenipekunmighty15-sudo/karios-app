---
name: Kinetic Editorial Brutalism
colors:
  surface: '#10131b'
  surface-dim: '#10131b'
  surface-bright: '#363942'
  surface-container-lowest: '#0b0e16'
  surface-container-low: '#191b24'
  surface-container: '#1d1f28'
  surface-container-high: '#272a32'
  surface-container-highest: '#32343d'
  on-surface: '#e1e2ee'
  on-surface-variant: '#e3bfb2'
  inverse-surface: '#e1e2ee'
  inverse-on-surface: '#2d3039'
  outline: '#aa8a7e'
  outline-variant: '#5a4138'
  surface-tint: '#ffb59a'
  primary: '#ffb59a'
  on-primary: '#5b1b00'
  primary-container: '#f95e14'
  on-primary-container: '#4f1700'
  inverse-primary: '#a83900'
  secondary: '#ccc6bb'
  on-secondary: '#333029'
  secondary-container: '#4f4b43'
  on-secondary-container: '#c1bbb0'
  tertiary: '#ffba27'
  on-tertiary: '#422c00'
  tertiary-container: '#bd8700'
  on-tertiary-container: '#392600'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#802a00'
  secondary-fixed: '#e9e2d6'
  secondary-fixed-dim: '#ccc6bb'
  on-secondary-fixed: '#1e1b15'
  on-secondary-fixed-variant: '#4a463e'
  tertiary-fixed: '#ffdea9'
  tertiary-fixed-dim: '#ffba27'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4100'
  background: '#10131b'
  on-background: '#e1e2ee'
  surface-variant: '#32343d'
  pitch-black: '#04060D'
  obsidian-surface: '#0C0E17'
  obsidian-elevated: '#141724'
  molten-ember: '#E65100'
  electric-gold: '#FFB703'
  bone-white: '#D9D2C7'
  stark-white: '#FFFFFF'
  industrial-wire: '#222738'
  acid-glow: '#CCFF00'
typography:
  display-hero:
    fontFamily: Anton
    fontSize: 96px
    fontWeight: '400'
    lineHeight: 92px
    letterSpacing: 0.02em
  display-hero-mobile:
    fontFamily: Anton
    fontSize: 52px
    fontWeight: '400'
    lineHeight: 52px
    letterSpacing: 0.01em
  headline-xl:
    fontFamily: Anton
    fontSize: 64px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: 0.01em
  headline-xl-mobile:
    fontFamily: Anton
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0.01em
  headline-lg:
    fontFamily: Anton
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: Anton
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: 0.02em
  headline-md:
    fontFamily: Work Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Work Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Work Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-mono-lg:
    fontFamily: Space Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-mono-sm:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.12em
  badge-stamp:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.15em
spacing:
  gutter: 1.25rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
  space-2xl: 5rem
---

## Brand & Style

The design system channels an avant-garde youth conference identity—a visceral collision between runway editorial luxury, raw brutalist assembly, and kinetic digital subculture. It speaks to a hyper-connected, spiritually charged generation that rejects corporate sterility and generic tech tropes. The emotional response is immediate and visceral: urgent, sacred, electric, and unapologetically bold.

The aesthetic philosophy fuses **High-Fashion Editorial Brutalism** with **Kinetic Event Architecture**:
- **Anti-AI Texture**: Absolute rejection of vague multi-color gradient blobs, floating soft cards, and timid symmetrical paddings.
- **Physical Event Artifacts**: UI blocks mirror physical conference credentials, laminated backstage passes, industrial barcode ribbons, high-density badge stickers, and perforated admission stubs.
- **Tension & Scale Contrast**: Ultra-condensed display typography and explosive typographic scale set against microscopic monospaced metadata and refined bone-white serifs.
- **Industrial Precision**: Raw 1px technical hairpins, stark rectangular modularity, and high-contrast dark surfaces that evoke dark auditorium stage lighting cut through by blinding amber follow-spots.

## Colors

The palette is engineered around severe contrast, drawing the eye like a stage floodlight in a blacked-out arena. 

- **Primary (`#E65100` - Molten Ember)**: High-heat kinetic energy used for critical interactive anchors, live state indicators, primary registrations, and urgent call-to-actions.
- **Secondary (`#D9D2C7` - Bone White)**: Editorial newsprint tone used for primary readable text, section dividers, and refined labels to prevent blinding eye strain while retaining high contrast against obsidian grounds.
- **Tertiary (`#FFB703` - Electric Gold)**: Secondary kinetic punch used for active countdown timers, status stamps, delegate tier tags, and highlight accents.
- **Neutral (`#04060D` - Pitch Black)**: The stage floor. A saturated, uncompromising deep void grounding all typography and media.

### Color Rules & Hierarchy
- Never use pure chromatic gradients for card backgrounds; backgrounds must remain strictly deep obsidian (`#04060D` through `#141724`) or pure inverted Bone White (`#D9D2C7`) for brutalist flash blocks.
- Molten Ember and Electric Gold are reserved for kinetic focal points: tickers, alert ribbons, registration passes, and dynamic hover states.
- Structural borders leverage `industrial-wire` (`#222738`) to frame content without breaking dark-mode immersion.

## Typography

The typography strategy builds high structural tension between condensed architectural force and utilitarian technical data:

- **Display & Section Titles (Anton)**: Ultra-tall, heavyweight, condensed proportions inspired by bold physical poster bills and monumental stage projections. Display text is always treated with tight line height and full uppercase capitalization to form monolithic typographic slabs.
- **Editorial Body (Work Sans)**: Neutral, hyper-legible, modern grotesque that provides smooth reading clarity across dark backgrounds, offsetting the aggressive character of Anton.
- **Technical Indexing & Stamps (Space Mono)**: Monospaced telemetry typography. Used for session dates, venue coordinates, ticket verification numbers, schedule metadata, and brutalist stamp overlays. Always set in uppercase with deliberate letter-spacing (`0.08em` to `0.15em`).

### Typographic Rules
- All primary headings (`display-hero`, `headline-xl`, `headline-lg`) must be set in uppercase (`text-transform: uppercase`).
- Section indices and stamps must precede headings using monospaced brackets (e.g., `[ 01 // KEYNOTE SESSION ]`).
- High-impact kinetic statistics pair huge display numbers with trailing mono descriptions.

## Layout & Spacing

The layout is built on an asymmetric, editorial grid system inspired by physical broadsheet newspapers, luxury lookbooks, and festival stage breakdowns:

- **Desktop (1200px+)**: A strict 12-column modular framework with 2rem gutters and generous 3rem boundary margins. Layouts embrace deliberate asymmetry—hero headers spanning 9 columns while 3 columns run a technical live ticker or vertical orientation bar.
- **Tablet (768px - 1199px)**: A 6-column fluid structure where multi-column editorial modules collapse into staggered 4/2 or alternating 3/3 layouts.
- **Mobile (< 768px)**: A 4-column layout running edge-to-edge with 1rem canvas margins. Content stacks vertically with full-width cards framed by continuous 1px technical lines.

### Section Architecture & Rhythms
- Blocks are delineated by crisp 1px borders rather than empty floating islands. 
- Use continuous looping marquee banners (infinite text tickers) between macro sections to break the rhythm and maintain dynamic kinetic motion.
- Spacing rhythm alternates strictly: tight, high-density groupings (`space-xs` to `space-sm`) inside card badges and stamp headers, contrasting against monolithic macro pauses (`space-2xl`) between programmatic conference acts.

## Elevation & Depth

This design system deliberately rejects blurred drop shadows, multi-colored ambient halos, and skeuomorphic elevations. Depth is achieved purely through **structural surface tiers, raw mechanical borders, and inverted tactile layering**:

1. **Base Surface Layer (`#04060D`)**: The primary stage ground. Absorbs light and frames high-contrast visuals.
2. **Elevated Structural Containers (`#0C0E17` to `#141724`)**: Solid obsidian planes bounded by crisp 1px borders (`#222738`). Cards never float via blur; they exist as rigid geometric panels welded to the grid.
3. **Hard Brutalist Offsets (Tactile Shadow)**: When physical elevation is necessary (e.g., active passes, floating badge tags, primary action triggers), employ sharp, unblurred offset drop-blocks:
   - `box-shadow: 4px 4px 0px 0px #E65100` (Molten Ember) or `box-shadow: 4px 4px 0px 0px #D9D2C7` (Bone White).
4. **Perforated Separators**: Use dotted or dashed 1px borders (`border-style: dashed`) to simulate tear-off physical ticket stubs between adjacent credential modules.

## Shapes

The geometric identity is uncompromisingly **sharp (0px roundedness)**:

- Every card, container, button, dialog, and sticker adheres to hard right angles (`roundedness: 0`). This reinforces architectural authority, raw brutalist discipline, and event credential metaphors.
- Diagonal corner notches (cut-corner angled bevels of 8px to 12px via CSS clip-path) are utilized exclusively on VIP badge passes and conference ticket containers.
- The single deliberate exception to the sharp rule is the **Functional Pill Tag**: Status indicators and conference delegate categories may use extreme full-radius pill silhouettes (`border-radius: 9999px`) to emulate physical vinyl convention wristbands or adhesive verification stickers.

## Components

### Buttons & Kinetic Triggers
- **Primary Action (Register / Access Pass)**: Solid Molten Ember (`#E65100`) background with stark black text (`#04060D`), set in uppercase `Anton` or bold `Space Mono`. Zero border radius. Sharp 4px offset shadow in `#D9D2C7`. On hover, the offset snaps to `0px 0px` with an immediate background inversion to `#FFB703`.
- **Secondary Action (Explore Lineup / Schedule)**: Transparent obsidian background with a 1px solid `#D9D2C7` border and Bone White text. Hover state inverts background to Bone White and text to Pitch Black.
- **Icon Buttons**: Strict 44x44px squares encased in 1px `#222738` borders with centered technical glyphs.

### Chips, Tags & Badges
- **Delegate Pill**: Full pill shape (`border-radius: 9999px`), 1px solid border in `#FFB703`, housing uppercase mono labels (e.g., `// VIP ACCESS`, `DELEGATE [CCI-2026]`).
- **Official Stamp Tag**: Rotated (-2deg to 3deg) rectangular brutalist sticker with high-density double border (solid 1px outline with 1px inset margin) and micro mono stamp typography (`VERIFIED ATTENDEE // 2026`).

### Cards & Ticket Modules
- **Conference Pass / Ticket Stub**: Split-panel modular card. Left panel (75% width) holds delegate name, conference act, venue data, and typography lockup. Right panel (25% width) holds a vertical numeric barcode, serial key, and QR code, separated by a vertical dashed tear-off line (`1px dashed #222738`).
- **Speaker Card**: High-contrast, duotone or greyscale photography overlaid with high-contrast text locked to the bottom edge. Includes a top-right mono badge index (`[SPKR-04]`).

### Form Inputs & Text Fields
- **Input Fields**: Sharp rectangular fields with pitch-black backgrounds (`#04060D`) framed by 1px `#222738` borders. On focus, the border turns into a razor-sharp 1px `#E65100` outline with zero blur glow.
- **Labels**: Rendered in uppercase `label-mono-sm` (`Space Mono`), positioned outside the input with an indexing prefix (`01 // EMAIL ADDRESS`).

### Checkboxes & Radios
- **Checkboxes**: 18x18px sharp squares with a 1px `#D9D2C7` border. When checked, the box fills with `#E65100` and displays a solid sharp black diagonal checkmark.
- **Radio Buttons**: 18x18px sharp square-in-square indicator (outer sharp square frame, inner sharp 8x8px square fill when active).

### Kinetic Marquee Ribbons
- Full-bleed horizontal ribbons set with alternating fills: high-heat Molten Ember background with Pitch Black text, or Pitch Black background with Bone White text and 1px industrial top/bottom wire lines. Continuously looping uppercase display typography running live slogans, conference acts, and scripture anchors.